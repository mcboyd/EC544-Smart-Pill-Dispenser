PyOWM is a client Python wrapper library for the
OpenWeatherMap web API. It allows quick and easy consumption of OWM weather
data from Python applications via a simple object model and in a
human-friendly fashion.

